import { createBrowserHistory } from 'history';

// A singleton history object for easy API navigation
const history = createBrowserHistory();
export default history;
